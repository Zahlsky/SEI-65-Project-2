
const Spinner = () => {

  return (
    <h1>Spinner</h1>
  )

}

export default Spinner